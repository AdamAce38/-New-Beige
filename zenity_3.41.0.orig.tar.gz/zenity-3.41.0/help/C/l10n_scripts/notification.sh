#!/bin/sh
                                                                                                                                                             
/gnome/head/cvs/zenity/src/zenity --notification \
--window-icon="info" \
--text="There are system updates necessary!"
