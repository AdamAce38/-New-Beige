#include "error_macros.h"

void _error_break_function() {
	//just to break
}
