#include "audio_lock.h"

void AudioLock::lock() {

}

void AudioLock::unlock() {

}
