#ifndef EFFECTS_H
#define EFFECTS_H

#include "engine/audio_effect.h"

void register_effects(AudioEffectFactory *p_factory);

#endif // EFFECTS_H
