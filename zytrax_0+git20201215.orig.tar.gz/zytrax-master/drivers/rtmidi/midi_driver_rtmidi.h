#ifndef MIDI_DRIVER_RTMIDI_H
#define MIDI_DRIVER_RTMIDI_H

//

void register_rtmidi_driver();
void unregister_rtmidi_driver();

#endif // MIDI_DRIVER_RTMIDI_H
