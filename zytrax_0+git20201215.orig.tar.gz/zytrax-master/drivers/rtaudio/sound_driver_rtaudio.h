#ifndef SOUND_DRIVER_RTAUDIO_H
#define SOUND_DRIVER_RTAUDIO_H

#include "engine/sound_driver.h"

void register_rtaudio_driver();
void cleanup_rtaudio_driver();

#endif // SOUND_DRIVER_RTAUDIO_H
