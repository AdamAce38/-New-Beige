#ifndef ICONS_H
#define ICONS_H

#include "rstring.h"
#include <gtkmm.h>

Gtk::Image create_image_from_icon(const String &p_name);

#endif // ICONS_H
